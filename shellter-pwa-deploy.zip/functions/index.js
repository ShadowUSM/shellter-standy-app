/**
 * Serwerowy proxy do DeepL API.
 *
 * DeepL świadomie blokuje zapytania wysyłane bezpośrednio z przeglądarki
 * (CORS 403) — wymaga, żeby klucz API i samo zapytanie szły przez własny
 * serwer. Ta funkcja robi dokładnie to: aplikacja (Hosting) woła ten adres,
 * funkcja doklejone klucz API (bezpiecznie schowany jako sekret, nigdy nie
 * trafia do przeglądarki) i przekazuje zapytanie dalej do DeepL.
 *
 * Klucz ustawia się RAZ poleceniem (w Cloud Shell):
 *   firebase functions:secrets:set DEEPL_API_KEY
 * a funkcję wdraża się poleceniem:
 *   firebase deploy --only functions
 */

const functions = require('firebase-functions');

// Docelowy język DeepL wymaga wariantu dla angielskiego (EN-GB/EN-US),
// samo "EN" jako język docelowy nie jest już akceptowane.
var TARGET_LANG_MAP = {
  en: 'EN-GB',
  de: 'DE'
};

exports.deeplTranslate = functions
  .runWith({ secrets: ['DEEPL_API_KEY'] })
  .region('europe-west1')
  .https.onRequest(async function(req, res){
    res.set('Access-Control-Allow-Origin', '*');
    res.set('Access-Control-Allow-Methods', 'POST, OPTIONS');
    res.set('Access-Control-Allow-Headers', 'Content-Type');

    if(req.method === 'OPTIONS'){
      res.status(204).send('');
      return;
    }
    if(req.method !== 'POST'){
      res.status(405).json({ error: 'Dozwolona jest tylko metoda POST' });
      return;
    }

    var body = req.body || {};
    var text = typeof body.text === 'string' ? body.text.trim() : '';
    var targetLangRaw = typeof body.targetLang === 'string' ? body.targetLang.toLowerCase() : '';
    var targetLang = TARGET_LANG_MAP[targetLangRaw];

    if(!text){
      res.status(400).json({ error: 'Brak pola "text" do przetłumaczenia' });
      return;
    }
    if(!targetLang){
      res.status(400).json({ error: 'Nieobsługiwany język docelowy — dozwolone: en, de' });
      return;
    }

    var apiKey = process.env.DEEPL_API_KEY;
    if(!apiKey){
      console.error('Brak DEEPL_API_KEY — sekret nie został ustawiony (firebase functions:secrets:set DEEPL_API_KEY)');
      res.status(500).json({ error: 'Serwer nie ma skonfigurowanego klucza DeepL' });
      return;
    }

    // Darmowe klucze DeepL zawsze kończą się sufiksem ":fx" — po tym rozpoznaje
    // się, na który adres API wysłać zapytanie (darmowy vs płatny).
    var isFreeKey = apiKey.trim().endsWith(':fx');
    var endpoint = isFreeKey
      ? 'https://api-free.deepl.com/v2/translate'
      : 'https://api.deepl.com/v2/translate';

    try {
      var deeplResponse = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Authorization': 'DeepL-Auth-Key ' + apiKey.trim(),
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          text: [text],
          source_lang: 'PL',
          target_lang: targetLang
        })
      });

      if(!deeplResponse.ok){
        var errBody = await deeplResponse.text();
        console.error('DeepL API error', deeplResponse.status, errBody);
        res.status(deeplResponse.status === 429 ? 429 : 502).json({
          error: 'Błąd DeepL API (status ' + deeplResponse.status + ')'
        });
        return;
      }

      var data = await deeplResponse.json();
      var translated = data && data.translations && data.translations[0] && data.translations[0].text;
      if(!translated){
        res.status(502).json({ error: 'DeepL nie zwrócił tłumaczenia' });
        return;
      }

      res.status(200).json({ translatedText: translated });
    } catch(err){
      console.error('Błąd wywołania DeepL:', err);
      res.status(500).json({ error: 'Błąd serwera podczas wywołania DeepL' });
    }
  });
