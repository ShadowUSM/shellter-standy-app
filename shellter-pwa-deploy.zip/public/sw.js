// Service Worker — Kreator Standów Bufetowych (Shellter Hotel)
//
// Strategia: "network-first" dla samej strony (index.html), żeby użytkownicy
// online zawsze dostawali najświeższą wersję aplikacji po aktualizacji —
// z zapisem do cache jako kopii zapasowej. Gdy sieć nie odpowiada (offline),
// aplikacja wczytuje się z tej zapisanej kopii. Dane standów i tak są
// synchronizowane oddzielnie przez Firestore (który ma własny tryb offline),
// więc to dotyczy wyłącznie "powłoki" aplikacji (HTML/CSS/JS/ikony).
//
// Numer wersji cache trzeba ręcznie podbić przy każdej większej aktualizacji
// aplikacji, żeby wymusić odświeżenie zapisanej kopii u wszystkich.
const CACHE_VERSION = 'kreator-standow-v23';

const APP_SHELL = [
  './',
  './index.html',
  './manifest.json'
];

self.addEventListener('install', function(event){
  event.waitUntil(
    caches.open(CACHE_VERSION).then(function(cache){
      return cache.addAll(APP_SHELL);
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', function(event){
  event.waitUntil(
    caches.keys().then(function(keys){
      return Promise.all(
        keys.filter(function(key){ return key !== CACHE_VERSION; })
            .map(function(key){ return caches.delete(key); })
      );
    })
  );
  self.clients.claim();
});

self.addEventListener('fetch', function(event){
  if(event.request.method !== 'GET') return;

  // Kluczowe: Service Worker ma obsługiwać WYŁĄCZNIE zasoby własnej domeny
  // (HTML, ikony, manifest). Zapytania do innych domen — a w szczególności
  // do Firestore (firestore.googleapis.com) — muszą przejść obok, nietknięte.
  // W przeciwnym razie SW zaburza mechanizm łączności Firestore, przez co
  // aplikacja utyka w trybie "tylko z pamięci lokalnej" i nigdy nie pokazuje
  // statusu "Online" — to udokumentowany, znany problem tego wzorca.
  var requestUrl = new URL(event.request.url);
  if(requestUrl.origin !== self.location.origin) return;

  // Nawigacja (wczytanie samej strony) — najpierw sieć, potem cache.
  if(event.request.mode === 'navigate'){
    event.respondWith(
      fetch(event.request).then(function(response){
        var copy = response.clone();
        caches.open(CACHE_VERSION).then(function(cache){ cache.put(event.request, copy); });
        return response;
      }).catch(function(){
        return caches.match('./index.html');
      })
    );
    return;
  }

  // Pozostałe zasoby (ikony, manifest itd.) — najpierw cache, potem sieć.
  event.respondWith(
    caches.match(event.request).then(function(cached){
      return cached || fetch(event.request).then(function(response){
        var copy = response.clone();
        caches.open(CACHE_VERSION).then(function(cache){ cache.put(event.request, copy); });
        return response;
      });
    }).catch(function(){
      return caches.match(event.request);
    })
  );
});
